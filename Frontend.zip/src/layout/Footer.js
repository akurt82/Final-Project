import React from "react";

export default function Footer() {
  return (
    <>
      <div className="footer">
        <h6>Copyright © 2022 On Point. All rights reserved. By Abdulaziz, Neimante, Seo.</h6>
      </div>
    </>
  );
}
