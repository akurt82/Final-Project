// import Header from "./layout/Header";
// import Main from "./components/Main";
// import Sidebar from "./layout/Sidebar";
// import SidebarEx from "./components/Sidebar-ex";
import "./App.css";
// import Layout from "./layout/Layout";
import LayoutMain from "./layout/LayoutMain";
// import { Box } from "@mui/material";
// import { Header } from "./layout/Header";
// import Footer from "./layout/Footer";
// import SearchBar from "./components/SearchBar";
import "./Message.css"
function App() {
  
  return (
    
    <LayoutMain>
     
    </LayoutMain>
  

  );

}

export default App;
