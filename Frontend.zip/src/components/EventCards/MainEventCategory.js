import React from 'react'

function MainEventCategory() {
    // {tbl_events.map((item) => {
    //     return (
    //       <ListItem
    //         className="row"
    //         key={item.id}
    //         id={window.location.pathname === item.link ? "active" : ""}
    //         onClick={() => {
    
    //           if (item.id === 9) {
    //             sessionStorage.setItem("logged", "")
    //             sessionStorage.setItem("userid", "")
    //             window.location.href = "http://localhost:3000/"
    //           } else 
    //           window.location.pathname = item.link;
    //         }}
    //       >
    //         <ListItemIcon
    //           sx={{
    //             color: "#fff",
    //             display: "flex",
    //             m: "0 auto",
    //             flex: "30%",
    //             cursor: "pointer",
    //             ml: "15px",
    //           }}
    //         >
    //           {item.icon}
    //         </ListItemIcon>

    //         <ListItem
    //           sx={{
    //             fontsize: "18px",
    //             flex: "70%",
    //             cursor: "pointer",
    //             display: { display: isOpen ? "block" : "none" },
    //           }}
    //           className="sideTitle"
    //         >
    //           {item.title}
    //         </ListItem>
    //       </ListItem>
    //     );
    //   })}
  return (
    <div>MainEventCategory</div>
  )
}

export default MainEventCategory